import type { LayoutOptions, ParsedDiagram, Scene, TextMeasurer } from "../types.ts";
export declare function layoutExtended(parsed: ParsedDiagram, measure: TextMeasurer, options?: LayoutOptions): Scene | undefined;
