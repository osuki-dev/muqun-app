import type { DiagramIR, LayoutOptions, Primitive, Scene, TextMeasurer } from "../types.ts";
/** Measure the complete legend before selecting an arrangement for the host viewport. */
export declare function layoutPie(ir: DiagramIR, primitives: Primitive[], fontSize: number, measure: TextMeasurer, options: LayoutOptions, interactions: NonNullable<Scene["interactions"]>): void;
