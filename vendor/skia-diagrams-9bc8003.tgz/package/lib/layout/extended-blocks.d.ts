import type { LayoutOptions, ParsedDiagram, Scene, TextMeasurer } from "../types.ts";
/** Native board layouts: every primitive uses the shared renderer's theme tokens. */
export declare function layoutExtendedBlocks(parsed: ParsedDiagram, measure?: TextMeasurer, options?: LayoutOptions): Scene | undefined;
