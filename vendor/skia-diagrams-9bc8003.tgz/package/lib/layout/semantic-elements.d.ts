import type { DiagramPrimitiveSemantic, Edge, Primitive } from "../types.ts";
/** Authored edge IDs win; unnamed parallel edges get stable endpoint-local ordinals. */
export declare function edgeSemanticIdentifiers(edges: readonly Edge[]): string[];
export declare function tagPrimitiveRange(primitives: Primitive[], start: number, semantic: DiagramPrimitiveSemantic): void;
