import type { Point, Rect } from "../types.ts";
export interface LabelAnchor extends Point {
    id: string;
    width: number;
    height: number;
    radius?: number;
}
export type LabelObstacle = Rect | {
    cx: number;
    cy: number;
    radius: number;
};
export interface PlacedLabel extends Rect {
    id: string;
    /** A leader starts at the marker boundary, never through its center. */
    leader?: [Point, Point];
}
export declare function labelIntersectsObstacle(rect: Rect, obstacle: LabelObstacle, gap?: number): boolean;
/**
 * Preserve authored data positions, placing measured labels around them. Eight
 * directional candidates are searched in bounded rings. Labels that cannot fit
 * use a reserved callout gutter instead of hiding text or moving the data.
 */
export declare function placeLabels(labels: readonly LabelAnchor[], plot: Rect, obstacles?: readonly LabelObstacle[], options?: {
    gap?: number;
    gutterTop?: number;
    gutterWidth?: number;
}): PlacedLabel[];
