import type { Scene, TextMeasurer, DiagramError, LayoutOptions } from "../types.ts";
import type { DiagramTheme } from "../render/theme.ts";
export type SceneResult = {
    status: "ready";
    scene: Scene;
} | {
    status: "error";
    error: DiagramError;
} | {
    status: "unsupported";
    type: string;
};
export declare function sourceHash(source: string): string;
/** LRU owns only serializable scenes, never a native resource or shared Picture.
 * Full source is part of the key so hash collisions cannot return another graph. */
export declare class SceneCache {
    private maxEntries;
    private maxPrimitives;
    private entries;
    private cost;
    private pending;
    constructor(maxEntries?: number, maxPrimitives?: number);
    key(source: string, theme: unknown, fontKey: string): string;
    /** Colors and line weights affect replay, not geometry. Font identity is
     * supplied separately so host providers never share incompatible metrics. */
    layoutKey(source: string, theme: DiagramTheme, fontKey: string): string;
    get(key: string): SceneResult | undefined;
    prepare(key: string, source: string, measure: TextMeasurer, fontSize: number | LayoutOptions): SceneResult;
    prepareAsync(key: string, source: string, measure: TextMeasurer, fontSize: number | LayoutOptions): Promise<SceneResult>;
    private finish;
    get size(): number;
    get primitiveCount(): number;
}
