/** Async grammars share the same cancellation boundary as synchronous layouts. */
export declare function requestSceneAsync<T>(prepare: () => Promise<T>, schedule: (work: () => void) => {
    cancel(): void;
}, commit: (value: T) => void, onError: (error: unknown) => void): () => void;
