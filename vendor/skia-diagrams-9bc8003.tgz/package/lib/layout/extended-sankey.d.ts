import type { LayoutOptions, ParsedDiagram, Scene, TextMeasurer } from "../types.ts";
export declare function layoutExtendedSankey(parsed: ParsedDiagram, measure: TextMeasurer, options?: LayoutOptions): Scene | undefined;
