import type { DiagramIR } from "../types.ts";
/** Closed sibling handoffs share a decision rank but keep their authored edges.
 * Outgoing work beyond the sibling group requires ordinary Dagre ranks. */
export declare function terminalBranchHandoffs(ir: DiagramIR): Set<number>;
