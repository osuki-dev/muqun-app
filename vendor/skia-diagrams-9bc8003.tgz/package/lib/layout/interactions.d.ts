import type { DiagramInteraction } from "../types.ts";
/** Keep visual and semantic hit geometry aligned after title or bounds translation. */
export declare function translateInteraction(item: DiagramInteraction, dx: number, dy: number): DiagramInteraction;
