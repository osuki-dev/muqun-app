import type { DiagramIR, LayoutOptions, TextMeasurer } from "../types.ts";
import type { LayoutGraph } from "./graph.ts";
/** A narrow reading layout preserves every graph edge while stacking table cards.
 * Each compound remains a real nested frame; routing uses a reserved outer lane. */
export declare function compactTableGraph(ir: DiagramIR, sizes: Map<string, {
    width: number;
    height: number;
}>, measure: TextMeasurer, options: LayoutOptions, ranked: LayoutGraph, distributePorts?: boolean): LayoutGraph;
