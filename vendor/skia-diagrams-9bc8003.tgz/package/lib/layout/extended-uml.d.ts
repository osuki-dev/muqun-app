import type { LayoutOptions, ParsedDiagram, Scene, TextMeasurer } from "../types.ts";
/** SysML compartments, C4 descriptions and use-case actor silhouettes share only
 * routing. Their contents and visual semantics remain type-specific. */
export declare function layoutExtendedUml(parsed: ParsedDiagram, measure: TextMeasurer, options?: LayoutOptions): Scene | undefined;
