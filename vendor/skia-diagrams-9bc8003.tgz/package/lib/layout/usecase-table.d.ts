import type { Node, Primitive, Rect, Scene, TextMeasurer } from "../types.ts";
import type { UsecaseJsonRow } from "../parse/usecase-json.ts";
export interface UsecaseTableMetrics {
    width: number;
    height: number;
    headerHeight: number;
    keyWidth: number;
    rows: (UsecaseJsonRow & {
        height: number;
    })[];
}
/** JSON leaves remain separate key/value cells, including blank continuation keys. */
export declare function measureUsecaseTable(node: Node, measure: TextMeasurer, fontSize: number, maxWidth: number): UsecaseTableMetrics;
export declare function renderUsecaseTable(node: Node, rect: Rect, table: UsecaseTableMetrics, measure: TextMeasurer, fontSize: number, primitives: Primitive[], interactions: NonNullable<Scene["interactions"]>): void;
