import type { LayoutOptions, ParsedDiagram, Scene, TextMeasurer } from "../types.ts";
export declare function layoutDiagram(parsed: ParsedDiagram, measure?: TextMeasurer, options?: LayoutOptions): Scene;
