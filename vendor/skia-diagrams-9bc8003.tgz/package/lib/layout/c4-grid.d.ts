import type { DiagramIR, LayoutOptions, TextMeasurer } from "../types.ts";
/** C4 uses authored-order rows, independently for elements and boundaries. */
export declare function c4Grid(ir: DiagramIR, sizes: Map<string, {
    width: number;
    height: number;
}>, measure: TextMeasurer, options: LayoutOptions, configuration?: Record<string, string>): any;
