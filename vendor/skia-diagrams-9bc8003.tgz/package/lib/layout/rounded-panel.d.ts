import type { Primitive, Rect } from "../types.ts";
/** Filled panel contour with only the selected outside corners rounded. */
export declare function roundedPanel(rect: Rect, radius: number, corners: readonly [boolean, boolean, boolean, boolean], fill: string): Extract<Primitive, {
    type: "path";
}>;
