import type { DiagramIR, LayoutOptions, Primitive, Scene, TextMeasurer } from "../types.ts";
/** Narrow temporal diagrams retain authored ordering as vertical, readable sections. */
export declare function layoutCompactTemporal(ir: DiagramIR, kind: Scene["kind"], primitives: Primitive[], interactions: NonNullable<Scene["interactions"]>, measure: TextMeasurer, options: LayoutOptions): boolean;
