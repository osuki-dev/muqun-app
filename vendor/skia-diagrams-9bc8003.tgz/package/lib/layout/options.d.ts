import type { LayoutOptions } from "../types.ts";
/** Finite host/config dimensions with explicit per-use bounds. */
export declare function boundedNumber(value: unknown, fallback: number, min?: number, max?: number): number;
/** Normalize host geometry once before dispatching to any diagram family. */
export declare function normalizeLayoutOptions(options: LayoutOptions): LayoutOptions;
