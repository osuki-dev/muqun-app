import type { DiagramIR, LayoutOptions, Primitive, Scene, TextMeasurer } from "../types.ts";
/** Quadrant data coordinates and styles stay authored; only annotations move. */
export declare function layoutQuadrant(ir: DiagramIR, primitives: Primitive[], fontSize: number, measure: TextMeasurer, options: LayoutOptions, interactions: NonNullable<Scene["interactions"]>, unboundedMeasure?: TextMeasurer): void;
