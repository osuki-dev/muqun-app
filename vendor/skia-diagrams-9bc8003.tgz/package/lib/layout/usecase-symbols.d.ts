import type { Node, Primitive, Rect, TextMeasurer } from "../types.ts";
/** Icons are host-owned native primitives. An unregistered name uses Mermaid's fallback. */
export type UsecaseIconResolver = (name: string, rect: Rect) => readonly Primitive[] | undefined;
export interface UsecaseActorOptions {
    fontSize?: number;
    radius?: number;
    strokeWidth?: number;
    measure?: TextMeasurer;
}
/** Native geometry follows Mermaid's 56 × 72 actor figure, without icon fonts or SVG. */
export declare function renderUsecaseActor(node: Node, rect: Rect, primitives: Primitive[], resolveIcon?: UsecaseIconResolver, options?: UsecaseActorOptions): void;
/** Business use cases carry a diagonal chord at the right edge of their ellipse. */
export declare function renderUsecaseBusinessMark(node: Node, rect: Rect, primitives: Primitive[]): void;
