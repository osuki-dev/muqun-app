import { OfficialScene } from "./context.ts";
import { type ArchitectureAlignment } from "./architecture-alignment.ts";
interface ArchitectureData {
    alignments?: ArchitectureAlignment[];
    services: {
        id: string;
        title?: string;
        icon?: string;
        iconText?: string;
        in?: string;
    }[];
    junctions: {
        id: string;
        in?: string;
    }[];
    groups: {
        id: string;
        title?: string;
        in?: string;
        icon?: string;
    }[];
    edges: {
        lhsId: string;
        rhsId: string;
        lhsDir: string;
        rhsDir: string;
        lhsInto: boolean;
        rhsInto: boolean;
        lhsGroup?: boolean;
        rhsGroup?: boolean;
        title?: string;
    }[];
}
export declare function architecture(scene: OfficialScene, data: ArchitectureData): void;
export {};
