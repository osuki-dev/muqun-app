import type { Rect } from "../../types.ts";
import type { OfficialScene } from "./context.ts";
/** Native vector symbols shared by service cards and group headings. */
export declare function architectureIcon(scene: OfficialScene, icon: string, rect: Rect, stroke: string): boolean;
