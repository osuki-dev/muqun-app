import { OfficialScene } from "./context.ts";
import type { CynefinData } from "./maps.ts";
/** Preserve the domain matrix while reserving a complete central confusion band. */
export declare function narrowCynefin(scene: OfficialScene, data: CynefinData, width: number): void;
