import { OfficialScene } from "./context.ts";
interface Frame {
    $type?: string;
    name: string;
    modelEntityType: string;
    entityIdentifier: unknown;
    sourceFrames: unknown[];
    dataInlineValue?: string;
    dataReference?: unknown;
}
interface EventModelData {
    frames: Frame[];
    dataEntities: {
        name: string;
        dataBlockValue: string;
    }[];
    noteEntities: {
        sourceFrame: unknown;
        dataBlockValue: string;
    }[];
}
export declare function eventmodeling(scene: OfficialScene, data: EventModelData): void;
export {};
