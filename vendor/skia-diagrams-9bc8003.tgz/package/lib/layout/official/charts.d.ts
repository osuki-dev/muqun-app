import { OfficialScene } from "./context.ts";
interface PacketData {
    config?: {
        packet?: {
            bitsPerRow?: number;
            showBits?: boolean;
            bitOrder?: string;
        };
    };
    blocks: {
        start: number;
        end?: number;
        bits?: number;
        label: string;
    }[];
}
export declare function packet(scene: OfficialScene, data: PacketData): void;
interface RadarData {
    config?: {
        radar?: {
            axisScaleFactor?: number;
            curveTension?: number;
        };
        themeVariables?: {
            radar?: {
                curveOpacity?: number;
            };
            [key: string]: unknown;
        };
    };
    axes: {
        name: string;
        label?: string;
    }[];
    curves: {
        name: string;
        label?: string;
        entries: {
            value: number;
            axis?: unknown;
        }[];
    }[];
    options: {
        name: string;
        value: unknown;
    }[];
}
export declare function radar(scene: OfficialScene, data: RadarData): void;
interface TreemapData {
    config?: {
        treemap?: {
            diagramPadding?: number;
            padding?: number;
            valueFormat?: string;
            nodeWidth?: number;
            nodeHeight?: number;
        };
    };
    TreemapRows: {
        indent?: string | number;
        item?: {
            $type: string;
            name: string;
            value?: number;
            classSelector?: string;
        };
        className?: string;
        styleText?: string;
    }[];
}
/** Squarified sibling areas preserve nested section frames and authored styles. */
export declare function treemap(scene: OfficialScene, data: TreemapData): void;
export {};
