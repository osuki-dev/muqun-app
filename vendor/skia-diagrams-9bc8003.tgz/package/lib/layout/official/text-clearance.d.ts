import type { Primitive } from "../../types.ts";
/** Leave small, transparent gaps where straight dependency strokes meet labels. */
export declare function clearTextFromPaths(primitives: readonly Primitive[], padding?: number): Primitive[];
