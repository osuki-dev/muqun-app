import type { Rect } from "../../types.ts";
/** Squarified treemap rows minimize their worst aspect ratio. Input order is
 * preserved; callers can sort siblings by weight before tiling. Geometry only,
 * with no renderer, font, hierarchy or theme ownership. */
export declare function squarify(weights: readonly number[], bounds: Rect): Rect[];
