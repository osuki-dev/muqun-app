import type { Point } from "../../types.ts";
export interface ArchitectureAlignment {
    direction: "row" | "column";
    members: string[];
}
/** Equality groups plus ordered tracks; longest-path ranks avoid iterative drift. */
export declare function alignArchitecture(positions: Map<string, Point>, alignments: ArchitectureAlignment[]): void;
