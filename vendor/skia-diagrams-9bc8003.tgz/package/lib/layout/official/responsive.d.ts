import type { LayoutOptions, ParsedDiagram, Scene, TextMeasurer } from "../../types.ts";
/** Diagram frames and their typography scale together when larger host text
 * would otherwise collide with fixed semantic regions. Host padding stays exact. */
export declare function responsiveScene(parsed: ParsedDiagram, measure: TextMeasurer, options: LayoutOptions, layout: (parsed: ParsedDiagram, measure: TextMeasurer, options: LayoutOptions) => Scene | undefined): Scene | undefined;
