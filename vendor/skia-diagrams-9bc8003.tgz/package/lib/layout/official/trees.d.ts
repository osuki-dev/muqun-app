import { OfficialScene } from "./context.ts";
interface TreeData {
    config?: {
        treeView?: {
            rowIndent?: number;
            lineThickness?: number;
            showIcons?: boolean;
            defaultIconPack?: string;
            filenameIcons?: Record<string, string>;
            extensionIcons?: Record<string, string>;
        };
        themeVariables?: {
            treeView?: {
                labelFontSize?: string;
                labelColor?: string;
                lineColor?: string;
            };
        };
    };
    nodes: {
        name: string;
        indent?: string | number;
        descAnnotation?: string;
        iconAnnotation?: string;
    }[];
}
export declare function treeview(scene: OfficialScene, data: TreeData): void;
export {};
