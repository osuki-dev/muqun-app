import { OfficialScene } from "./context.ts";
interface WardleyData {
    size?: {
        width: number;
        height: number;
    };
    evolution?: {
        stages: {
            name: string;
            secondName?: string;
            boundary?: number;
        }[];
    };
    components: {
        name: string;
        visibility: number;
        evolution: number;
        inertia?: boolean;
        label?: {
            negX?: boolean;
            negY?: boolean;
            offsetX: number;
            offsetY: number;
        };
        decorator?: {
            strategy: string;
        };
    }[];
    anchors: {
        name: string;
        visibility: number;
        evolution: number;
    }[];
    links: {
        from: string;
        to: string;
        arrow?: string;
        fromPort?: string;
        toPort?: string;
        linkLabel?: string;
    }[];
    accelerators: {
        name: string;
        x: number;
        y: number;
    }[];
    deaccelerators: {
        name: string;
        x: number;
        y: number;
    }[];
    annotation: {
        number: number;
        x: number;
        y: number;
        text: string;
    }[];
    annotations: {
        x: number;
        y: number;
    }[];
    evolves: {
        component: string;
        target: number;
    }[];
    notes: {
        text: string;
        visibility: number;
        evolution: number;
    }[];
    pipelines: {
        parent: string;
        components: {
            name: string;
            evolution: number;
        }[];
    }[];
}
export declare function wardley(scene: OfficialScene, data: WardleyData): void;
export interface CynefinData {
    domains: {
        domain: string;
        items: {
            label: string;
        }[];
    }[];
    transitions: {
        from: string;
        to: string;
        label: string;
    }[];
}
export declare function cynefin(scene: OfficialScene, data: CynefinData): void;
export {};
