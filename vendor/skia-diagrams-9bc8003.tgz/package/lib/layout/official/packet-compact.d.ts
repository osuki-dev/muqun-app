import { OfficialScene } from "./context.ts";
interface PacketData {
    config?: {
        packet?: {
            bitsPerRow?: number;
            showBits?: boolean;
            bitOrder?: string;
        };
    };
    blocks: {
        start: number;
        end?: number;
        bits?: number;
        label: string;
    }[];
}
/** Preserve bit geometry; narrow fields get readable range-labelled rows instead of tiny type. */
export declare function compactPacket(scene: OfficialScene, data: PacketData): boolean;
export {};
