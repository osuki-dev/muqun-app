import type { DiagramKind, DiagramInteraction, LayoutOptions, Point, Primitive, Rect, Scene, Shape, TextMeasurer } from "../../types.ts";
/** Shared native primitive construction. Geometry remains independent of the palette. */
export declare class OfficialScene {
    readonly kind: DiagramKind;
    readonly measure: TextMeasurer;
    readonly options: LayoutOptions;
    readonly title?: string | undefined;
    readonly primitives: Primitive[];
    readonly interactions: DiagramInteraction[];
    readonly fontSize: number;
    readonly padding: number;
    readonly top: number;
    constructor(kind: DiagramKind, measure: TextMeasurer, options: LayoutOptions, title?: string | undefined);
    text(value: string, x: number, y: number, width?: number, color?: string, weight?: number, fontSize?: number): void;
    box(rect: Rect, fill?: string | undefined, stroke?: string, shape?: Shape, id?: string): void;
    line(points: Point[], stroke?: string, arrow?: boolean, dash?: number[]): void;
    data(id: string, label: string, bounds: Rect, value?: number, tooltip?: string): void;
    icon(name: string, bounds: Rect): boolean;
    finish(): Scene;
}
export declare function reference(value: unknown): string;
export declare function clamp(value: number, min?: number, max?: number): number;
