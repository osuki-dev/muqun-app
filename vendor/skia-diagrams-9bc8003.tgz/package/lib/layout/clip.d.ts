import type { Point, Rect } from "../types.ts";
/** Liang–Barsky clipping preserves linear intersections at plot boundaries. */
export declare function clipPolyline(points: Point[], rect: Rect): Point[][];
