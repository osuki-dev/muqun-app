import type { DiagramIR, LayoutOptions, TextMeasurer, Point } from "../types.ts";
export interface LayoutGraphNode {
    width: number;
    height: number;
    x: number;
    y: number;
}
export interface LayoutGraphEdge {
    points: Point[];
    x: number;
    y: number;
}
export interface LayoutGraphDescriptor {
    v: string;
    w: string;
    name?: string;
}
/** Only operations used by layout consumers; mutation results are deliberately
 * independent of Graphlib's fluent setters or Map's deletion boolean. */
export interface LayoutGraph {
    node(id: string): LayoutGraphNode;
    nodes(): string[];
    edges(): LayoutGraphDescriptor[];
    outEdges(from: string, to?: string): LayoutGraphDescriptor[] | undefined;
    removeEdge(edge: LayoutGraphDescriptor): void;
    setEdge(from: string, to: string, label: LayoutGraphEdge, name?: string): void;
    edge(edge: LayoutGraphDescriptor): LayoutGraphEdge;
}
/** Dagre/graphlib use object-backed indexes internally. Keep legal Mermaid IDs
 * such as __proto__ away from those indexes and expose only semantic IDs. */
export declare function compoundLayout(ir: DiagramIR, sizes: Map<string, {
    width: number;
    height: number;
}>, measure: TextMeasurer, options: LayoutOptions, flowchart?: boolean): LayoutGraph;
