import type { LayoutOptions, ParsedDiagram, Scene, TextMeasurer } from "../types.ts";
/** Circle intersection area, used to respect authored set and overlap sizes. */
export declare function circleOverlap(a: number, b: number, distance: number): number;
export declare function layoutExtendedSets(parsed: ParsedDiagram, measure: TextMeasurer, options?: LayoutOptions): Scene | undefined;
