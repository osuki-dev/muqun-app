import type { Node, TextMeasurer } from "../types.ts";
export declare function entityHeader(node: Node): string;
/** Measure each ER cell with the exact weight used by native text replay. */
export declare function entityTable(node: Node, measure: TextMeasurer, fontSize: number, headerSize: number, paddingX: number, paddingY: number, rowGap: number, maxWidth?: number): {
    title: string;
    columns: ("comment" | "key" | "name" | "type")[];
    widths: number[];
    rowHeights: number[];
    dataHeights: number[];
    primaryHeights: number[];
    keyOnOwnLine: boolean[];
    stackedAttributes: boolean;
    stackedComments: boolean;
    headerHeight: number;
    width: number;
    height: number;
};
