import type { LayoutOptions, ParsedDiagram, Scene, TextMeasurer } from "../types.ts";
/** Official ASTs are translated directly into replayable native primitives. */
export declare function layoutOfficial(parsed: ParsedDiagram, measure?: TextMeasurer, options?: LayoutOptions): Scene | undefined;
