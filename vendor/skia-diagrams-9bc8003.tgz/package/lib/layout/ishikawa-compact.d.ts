import type { LayoutOptions, ParsedDiagram, Scene, TextMeasurer } from "../types.ts";
/** A vertical fishbone retains the common spine and cause hierarchy at readable native sizes. */
export declare function compactIshikawa(parsed: Extract<ParsedDiagram, {
    ir: unknown;
}>, measure: TextMeasurer, options: LayoutOptions): Scene;
