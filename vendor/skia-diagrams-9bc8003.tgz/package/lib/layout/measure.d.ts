import type { TextMeasurer } from "../types.ts";
/** Deterministic Node fallback; native callers inject Paragraph metrics. */
export declare const estimateText: TextMeasurer;
