import type { Primitive } from "../types.ts";
/** Own mutable scene geometry without mutating host-provided icon primitives. */
export declare function clonePrimitive(primitive: Primitive, dx?: number, dy?: number): Primitive;
/** Translate every scene-coordinate field, including authored gradients and sectors. */
export declare function translatePrimitive(primitive: Primitive, dx: number, dy: number): Primitive;
