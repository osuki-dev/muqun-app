import type { ParsedDiagram, TextMeasurer, LayoutOptions, Scene } from "../types.ts";
/** Native lifelines, activation bars, messages, notes, and structured fragments. */
export declare function layoutZenuml(parsed: ParsedDiagram, measure: TextMeasurer, options?: LayoutOptions): Scene | undefined;
