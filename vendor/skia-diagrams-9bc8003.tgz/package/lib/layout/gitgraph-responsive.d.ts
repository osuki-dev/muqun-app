import type { DiagramIR, LayoutOptions, Primitive, TextMeasurer } from "../types.ts";
/** A narrow viewport keeps time on the vertical axis. Lanes remain distinct,
 * and authored labels occupy measured rows beside the graph instead of shrinking. */
export declare function narrowGitgraph(ir: DiagramIR, branches: readonly (string | undefined)[], measure: TextMeasurer, options: LayoutOptions, dotRadius: number): Primitive[];
