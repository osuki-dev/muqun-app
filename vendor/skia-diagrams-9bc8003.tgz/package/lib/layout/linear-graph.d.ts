import type { Graph, GraphLabel, NodeLabel, EdgeLabel } from "@dagrejs/dagre";
/** A directed path needs no recursive ranking or crossing minimization. Dagre's
 * DFS grows with the path (including dummy ranks) and exhausts Hermes' native
 * stack for legal 300-node diagrams. Preserve its straight, unlabeled geometry
 * with an iterative pass; leave branched, cyclic and labeled graphs to Dagre. */
export declare function layoutLinearGraph(graph: Graph<GraphLabel, NodeLabel, EdgeLabel>): boolean;
