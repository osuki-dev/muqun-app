export interface MermaidFence {
    start: number;
    end: number;
    source: string;
    closed: boolean;
}
/** CommonMark fences: at most three leading spaces, matching character and length. */
export declare function findMermaidFences(markdown: string): MermaidFence[];
