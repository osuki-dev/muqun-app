import type { DiagramIR } from "../types.ts";
export declare function parseFlowchart(ir: DiagramIR, source: string): void;
