import type { ParsedDiagram } from "../types.ts";
/** Native extended grammars; unrelated types avoid reparsing YAML metadata. */
export declare function parseExtended(source: string): ParsedDiagram | undefined;
