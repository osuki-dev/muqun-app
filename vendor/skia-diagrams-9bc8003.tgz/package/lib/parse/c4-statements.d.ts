export interface C4Statement {
    text: string;
    /** One-based source line of the first non-whitespace character. */
    line: number;
}
/** Split declarations without treating quoted labels or multiline arguments as syntax. */
export declare function c4Statements(source: string): C4Statement[];
