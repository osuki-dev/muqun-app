export interface UsecaseJsonRow {
    key: string;
    accessibleKey: string;
    value: string;
}
/** Strict JSON tables preserve authored object order, including integer-looking keys. */
export declare function readUsecaseJson(source: string, line: number): {
    data: Record<string, unknown>;
    rows: UsecaseJsonRow[];
};
