import type { ParsedDiagram, Style } from "../types.ts";
export interface VennRegion {
    id: string;
    sets: string[];
    label: string;
    size: number;
    /** Explicit authored size; defaults only influence circle geometry. */
    authoredSize?: number;
    style: Style;
    opacity?: number;
    texts: {
        id: string;
        label: string;
        style: Style;
    }[];
}
export interface Cause {
    id: string;
    label: string;
    children: Cause[];
}
export declare function parseExtendedSets(source: string): ParsedDiagram | undefined;
