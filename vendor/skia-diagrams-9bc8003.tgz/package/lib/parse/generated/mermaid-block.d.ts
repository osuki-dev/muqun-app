export interface BlockGrammarContext {
    getLogger(): {
        debug(...args: unknown[]): void;
    };
    generateId(): string;
    typeStr2Type(value?: string): string;
    edgeStrToEdgeData(value: string): string;
    edgeStrToEdgeStartData(value: string): string;
    edgeStrToThickness(value: string): string;
    edgeStrToPattern(value: string): string;
    setHierarchy(value: unknown): void;
    linkNodes(from: unknown, link: unknown, to: unknown): unknown[];
    parseError(message: string, hash: {
        line?: number;
        loc?: {
            first_line?: number;
        };
    }): never;
}
/** The parser owns a fresh state for every call; consumers never touch generated tables. */
export declare function runOfficialBlockGrammar(source: string, context: BlockGrammarContext): void;
