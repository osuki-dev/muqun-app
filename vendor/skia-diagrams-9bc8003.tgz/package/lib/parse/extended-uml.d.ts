import type { ParsedDiagram } from "../types.ts";
export interface UmlNodeData {
    type: string;
    fields: Record<string, string>;
    classes?: string[];
}
export interface UmlData {
    nodes: Record<string, UmlNodeData>;
    layout?: Record<string, string>;
    c4Type?: string;
}
export declare function parseExtendedUml(source: string): ParsedDiagram | undefined;
