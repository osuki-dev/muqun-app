import type { ParsedDiagram } from "../types.ts";
export declare function parseDiagram(source: string): ParsedDiagram;
/** Official Langium grammars are loaded on demand, without a DOM or browser. */
export declare function parseDiagramAsync(source: string): Promise<ParsedDiagram>;
