import type { DiagramIR, DiagramKind } from "../types.ts";
/** Native class, state and ER grammar. Notes, interactions, styles and grouping
 * stay declarative; callbacks and links are dispatched only by the host. */
export declare function parseGraph(ir: DiagramIR, kind: DiagramKind, lines: {
    text: string;
    line: number;
}[]): void;
