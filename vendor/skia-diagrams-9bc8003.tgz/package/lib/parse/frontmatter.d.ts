/** Preserve line numbers while reading Mermaid's YAML front matter safely. */
export declare function readFrontMatter(source: string): {
    source: string;
    title?: string;
    config?: Record<string, unknown>;
};
