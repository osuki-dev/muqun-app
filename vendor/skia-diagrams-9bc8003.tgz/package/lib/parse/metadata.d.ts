import { readFrontMatter } from "./frontmatter.ts";
/** Deep mapping merge for official init/front-matter configuration, never prototypes. */
export declare function mergeDiagramConfig(...values: (Record<string, unknown> | undefined)[]): Record<string, unknown> | undefined;
/** Read metadata without running a diagram grammar; keep all diagnostic line offsets. */
export declare function readDiagramMetadata(source: string): ReturnType<typeof readFrontMatter>;
