/** One bounded YAML reader for front matter and Mermaid object attributes. */
export declare function readYaml(source: string, line: number, description: string, keys?: string[]): unknown;
export declare function readYamlMapping(source: string, line: number, description: string, keys?: string[]): Record<string, unknown>;
