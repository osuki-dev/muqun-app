import type { ParsedDiagram } from "../types.ts";
export interface BlockCell {
    id: string;
    span: number;
    space?: boolean;
    arrows?: string[];
    group?: BlockGroup;
}
export interface BlockGroup {
    id: string;
    label?: string;
    columns?: number;
    cells: BlockCell[];
}
export interface KanbanColumn {
    id: string;
    label: string;
    cards: KanbanCard[];
}
export interface KanbanCard {
    id: string;
    label: string;
    metadata: Record<string, string>;
}
export declare function parseExtendedBlocks(source: string): ParsedDiagram | undefined;
