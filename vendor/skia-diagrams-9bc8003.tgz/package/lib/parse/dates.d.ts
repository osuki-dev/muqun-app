/** Deterministic UTC subset, not the locale-dependent Date.parse grammar. */
export declare function parseDate(value: string, format: string): number;
export declare function formatAxisDate(time: number, format: string): string;
export declare function dateTicks(start: number, end: number): number[];
