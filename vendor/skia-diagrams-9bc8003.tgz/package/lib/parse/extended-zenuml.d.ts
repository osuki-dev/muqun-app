import type { ParsedDiagram } from "../types.ts";
/** ZenUML is parsed as a sequence of messages and nested scopes, never executed. */
export declare function parseZenuml(source: string): ParsedDiagram | undefined;
