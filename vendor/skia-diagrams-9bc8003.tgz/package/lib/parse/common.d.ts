import type { DiagramError, DiagramIR, Node, Style } from "../types.ts";
export declare class ParseFailure extends Error {
    detail: DiagramError;
    constructor(detail: DiagramError);
}
export declare function fail(line: number, message: string): never;
export declare function label(text: string): string;
export declare function emptyIR(): DiagramIR;
export declare function stripComment(source: string): string;
export declare function addNode(ir: DiagramIR, id: string, text?: string, shape?: Node["shape"], parent?: string): Node;
export declare function parseStyle(source: string): Style;
/** Split only outside quoted labels and node delimiters. */
export declare function splitStatements(source: string): {
    text: string;
    line: number;
}[];
