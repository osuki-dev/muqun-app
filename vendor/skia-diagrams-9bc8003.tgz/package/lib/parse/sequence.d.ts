import type { DiagramIR } from "../types.ts";
/** Native sequence syntax:
 * | Participants | participant/actor, aliases, symbol metadata, box groups, creation/destruction, menus |
 * | Messages | solid/dashed arrows, bidirectional arrows, cross/open/half endpoints, connections, self messages |
 * | Activations | activate/deactivate, +/- shorthand, nested stack offsets |
 * | Notes | left of/right of/over, aliases and line breaks |
 * | Fragments | loop/alt/else/opt/par/and/critical/option/break/rect, nested frames |
 * | Other | autonumber, title/accessibility labels, standalone %% comments |
 */
export declare function parseSequence(ir: DiagramIR, lines: {
    text: string;
    line: number;
}[]): void;
