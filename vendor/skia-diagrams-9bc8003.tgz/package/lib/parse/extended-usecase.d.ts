import type { ParsedDiagram } from "../types.ts";
/** Native use-case grammar: declarations, boundaries, associations and safe data tables. */
export declare function parseUsecase(source: string): ParsedDiagram | undefined;
