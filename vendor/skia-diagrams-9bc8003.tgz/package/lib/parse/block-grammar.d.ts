import type { DiagramIR } from "../types.ts";
/** Official syntax is generated at build time; only native semantic adaptation runs here. */
export declare function parseOfficialBlock(ir: DiagramIR, source: string): void;
