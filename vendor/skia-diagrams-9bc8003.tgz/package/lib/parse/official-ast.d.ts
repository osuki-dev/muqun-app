import type { ParsedDiagram } from "../types.ts";
/** Parse official grammars lazily without loading a DOM, browser, renderer, or fonts. */
export declare function parseOfficialAst(source: string): Promise<ParsedDiagram | undefined>;
