import type { DiagramIR, DiagramKind } from "../types.ts";
/** Native chart grammar. Authored style/configuration metadata is kept in IR data
 * for type-specific layouts; parsing never executes callbacks, icons or CSS. */
export declare function parseChart(ir: DiagramIR, kind: DiagramKind, lines: {
    text: string;
    line: number;
}[]): void;
