import type { ParsedDiagram } from "../types.ts";
export interface SankeyLink {
    source: string;
    target: string;
    value: number;
}
export interface SankeyData {
    links: SankeyLink[];
    config: Record<string, unknown>;
}
export declare function parseExtendedSankey(source: string): ParsedDiagram | undefined;
