import type { DiagramInteraction, Point, Rect, Scene } from "../types.ts";
/** Test semantic geometry rather than overlapping bounding boxes. */
export declare function hitTestInteraction(scene: Scene, point: Point): DiagramInteraction | undefined;
/** Invert the viewer centering, pan and zoom exactly before semantic hit testing. */
export declare function viewerPointToScene(point: Point, bounds: Rect, viewport: {
    width: number;
    height: number;
}, scale: number, pan: Point): Point;
