/** Pie can wrap its legend at readable size; other natural layouts keep authored geometry. */
export declare function inlineLayoutWidth(source: string, availableWidth: number | undefined, fitToViewport: boolean | undefined): number | undefined;
