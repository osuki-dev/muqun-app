import { type SkFont, type SkPicture, type SkPath, type SkTypefaceFontProvider } from "react-native-skia";
import type { Scene } from "../types.ts";
import { type NativeRenderAssets } from "../render/skia.ts";
import { recordNativeTraces } from "./native-trace.tsx";
import { type DiagramTheme } from "../render/theme.ts";
import { type NumericMotion, type PrimitiveMotionLayer } from "./primitive-motion-plan.ts";
export interface RecordedMotion {
    staticPicture: SkPicture;
    layers: (Omit<PrimitiveMotionLayer, "primitives"> & {
        picture?: SkPicture;
        markerPicture?: SkPicture;
        traces?: ReturnType<typeof recordNativeTraces>["traces"];
    })[];
    numbers: (NumericMotion & {
        font: SkFont;
        color: string;
        baseline: number;
        delay: number;
        span: number;
    })[];
    resources: (SkPicture | SkFont | SkPath)[];
}
/** Allocate once per recording. Every failure disposes the partial bundle. */
export declare function recordDiagramMotion(scene: Scene, theme: DiagramTheme, fonts?: SkTypefaceFontProvider, assets?: NativeRenderAssets): RecordedMotion;
