import type { NumericMotion } from "./primitive-motion-plan.ts";
import type { Primitive } from "../types.ts";
export declare function numericTiming(number: NumericMotion): {
    delay: number;
    span: number;
};
/** Retain the original Paragraph when a counter cannot reproduce host typography.
 * Four bounded groups wait for their latest member rather than exposing labels early. */
export declare function createNumericFallbacks(): {
    add(number: NumericMotion, timing: {
        delay: number;
        span: number;
    }): void;
    finish(): {
        primitives: Primitive[];
        delay: number;
        span: number;
    }[];
};
