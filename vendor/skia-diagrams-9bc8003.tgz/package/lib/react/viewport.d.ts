/** Fit may be smaller than 0.5 for large scenes, but 1x/6x always mean absolute
 * scene-point scale, not six times a tiny thumbnail. These functions are also
 * worklets so gestures do not send every pointer frame back to JavaScript. */
export declare function clampViewerZoom(scale: number, fit: number): number;
export declare function panLimit(sceneSize: number, viewportSize: number, scale: number): number;
export declare function inlineViewport(bounds: {
    width: number;
    height: number;
}, maxWidth: number, window: {
    width: number;
    height: number;
}, minScale?: number, maxHeight?: number, fitToViewport?: boolean): {
    width: number;
    height: number;
    contentWidth: number;
    contentHeight: number;
    overflow: boolean;
    scale: number;
};
