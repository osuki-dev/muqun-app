import { type SkPicture } from "react-native-skia";
import type { RecordedMotion } from "./record-motion.ts";
export declare function MotionPicture({ picture, motion, kind, onComplete, }: {
    picture: SkPicture;
    motion?: RecordedMotion;
    kind: string;
    onComplete?: () => void;
}): import("react").JSX.Element;
