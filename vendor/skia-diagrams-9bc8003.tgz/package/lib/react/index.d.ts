import type { DiagramExecutionState } from "./execution-state.ts";
export type { DiagramExecutionState, DiagramExecutionStatus } from "./execution-state.ts";
import { type RecordedMotion } from "./record-motion.ts";
import { type DiagramConfiguration } from "./provider.tsx";
export { DiagramProvider, useDiagramConfiguration, type DiagramConfiguration, type DiagramExpandIconProps, type DiagramViewerIconAction, type DiagramViewerIconProps, } from "./provider.tsx";
import { type ReactNode } from "react";
import { type StyleProp, type ViewStyle } from "react-native";
import { type SkPicture, type SkTypefaceFontProvider } from "react-native-skia";
import { type DiagramInteraction, type DiagramError, type Scene, type TextMeasurer, type DiagramTheme } from "../index.ts";
import { type NativeRenderAssets } from "../render/skia.ts";
export { createSkiaTextMeasurer, renderToPicture, renderToPng, type NativeRenderAssets, } from "../render/skia.ts";
type DiagramResult = {
    status: "ready";
    recordingKey: string;
    layoutKey: string;
    replayToken?: string | number;
    motionSession: number;
    scene: Scene;
    picture: SkPicture;
    motion?: RecordedMotion;
    onMotionComplete?: () => void;
    onRenderError: (error: unknown) => void;
    bounds: Scene["bounds"];
    theme: DiagramTheme;
    fontProvider?: SkTypefaceFontProvider;
    assets?: NativeRenderAssets;
} | {
    status: "error";
    error: DiagramError;
} | {
    status: "unsupported";
    type: string;
} | {
    status: "idle";
};
/** A picture belongs to one hook/Canvas, never to a global cache across Graphite views. */
export declare function useDiagram(source: string, theme: DiagramTheme, measure?: TextMeasurer, fontProvider?: SkTypefaceFontProvider, assets?: NativeRenderAssets, options?: {
    animate?: boolean;
    viewportWidth?: number;
    enabled?: boolean;
    replayToken?: string | number;
}): DiagramResult;
export interface DiagramProps {
    /** The host viewport owns visibility. Inactive diagrams release native recordings. */
    active?: boolean;
    source: string;
    theme?: Partial<DiagramTheme>;
    fontProvider?: SkTypefaceFontProvider;
    assets?: NativeRenderAssets;
    measure?: TextMeasurer;
    maxWidth?: number;
    execution?: DiagramExecutionState;
    /** Change this token to replay entrance motion without changing diagram geometry. */
    replayToken?: string | number;
    minScale?: number;
    /** Explicit viewport height enables internal vertical scrolling. Defaults to
     * natural page height; scenes taller than 1200pt use a 420pt expandable preview. */
    maxHeight?: number;
    /** Fit the natural layout uniformly in both dimensions without reflowing it. */
    fitToViewport?: boolean;
    onPress?: () => void;
    onInteraction?: (interaction: DiagramInteraction) => void;
    /** Render selected data below the canvas; return null to suppress the default detail. */
    renderDataDetail?: (selection: DiagramInteraction, dismiss: () => void) => ReactNode;
    /** Explicit top-right expand control; tapping the diagram never invokes this action. */
    onExpand?: () => void;
    renderExpandIcon?: DiagramConfiguration["renderExpandIcon"];
    expandButtonStyle?: StyleProp<ViewStyle>;
    /** Reveal the expand button on a tap without reserving a toolbar row. */
    expandControl?: "always" | "on-tap";
    onLongPress?: () => void;
    onError?: (error: DiagramError) => void;
    onReady?: (scene: Scene) => void;
    fallback?: (source: string, error?: DiagramError) => ReactNode;
    accessibilityLabel?: string;
    testID?: string;
}
export declare function DiagramFallback({ source, error, theme, }: {
    source: string;
    error?: DiagramError;
    theme?: DiagramTheme;
}): import("react").JSX.Element;
export declare function Diagram(props: DiagramProps): import("react").JSX.Element;
export interface DiagramViewerProps {
    /** Override the provider's viewer icon renderer; null/undefined retain default icons. */
    renderViewerIcon?: DiagramConfiguration["renderViewerIcon"];
    /** Suspend native recordings while the host screen is inactive. Defaults to true. */
    active?: boolean;
    labels?: Partial<{
        close: string;
        fit: string;
        actualSize: string;
        copy: string;
        svg: string;
        png: string;
    }>;
    /** Idle delay before hiding controls. Set to 0 to keep them visible. */
    toolbarAutoHideMs?: number;
    execution?: DiagramExecutionState;
    /** Change this token to replay entrance motion without changing diagram geometry. */
    replayToken?: string | number;
    source: string;
    theme?: Partial<DiagramTheme>;
    fontProvider?: SkTypefaceFontProvider;
    assets?: NativeRenderAssets;
    onClose: () => void;
    onInteraction?: (interaction: DiagramInteraction) => void;
    /** Render selected data below the canvas; return null to suppress the default detail. */
    renderDataDetail?: (selection: DiagramInteraction, dismiss: () => void) => ReactNode;
    onCopySource?: () => void;
    onExport?: (kind: "png" | "svg", data: Uint8Array | string) => void | Promise<void>;
}
export declare function DiagramViewer(props: DiagramViewerProps): import("react").JSX.Element;
