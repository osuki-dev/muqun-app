import type { PrimitiveMotionLayer } from "./primitive-motion-plan.ts";
/** Native trim applies only to stroke-only paths. A whole ineligible layer stays
 * in its original Picture, preserving both paint order and complete geometry. */
export declare function tracePaths(layer: PrimitiveMotionLayer, alreadyRecorded: number): ({
    type: "path";
    motion?: {
        axis: "x" | "y";
    };
    curves?: {
        control1: import("../types.ts").Point;
        control2: import("../types.ts").Point;
        end: import("../types.ts").Point;
    }[];
    gradient?: import("../types.ts").Style["gradient"];
    opacity?: number;
    points: import("../types.ts").Point[];
    start?: import("../types.ts").Marker;
    end?: import("../types.ts").Marker;
    stroke?: string;
    strokeWidth?: number;
    strokeRole?: import("../types.ts").Style["strokeRole"];
    dash?: number[];
    closed?: boolean;
    smooth?: boolean;
    fill?: string;
} & {
    semantic?: import("../types.ts").DiagramPrimitiveSemantic;
})[] | undefined;
