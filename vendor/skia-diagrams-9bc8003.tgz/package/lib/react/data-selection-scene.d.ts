import { type ReactNode } from "react";
import { type SkTypefaceFontProvider } from "react-native-skia";
import type { DiagramInteraction, Scene } from "../types.ts";
import { type NativeRenderAssets } from "../render/skia.ts";
import type { DiagramTheme } from "../render/theme.ts";
/** Native vector selection is shared by inline and expanded views. It preserves
 * the authored scene and its hit geometry, and records only when selection changes. */
export declare function DataSelectionScene({ scene, theme, fontProvider, assets, selection, onTakeOver, children, }: {
    scene: Scene;
    theme: DiagramTheme;
    fontProvider?: SkTypefaceFontProvider;
    assets?: NativeRenderAssets;
    selection?: DiagramInteraction;
    onTakeOver?: () => void;
    children: ReactNode;
}): import("react").JSX.Element;
