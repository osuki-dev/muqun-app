import { type SkTypefaceFontProvider } from "react-native-skia";
import type { Scene } from "../types.ts";
import type { DiagramTheme } from "../render/theme.ts";
import { type NativeRenderAssets } from "../render/skia.ts";
import { type DiagramExecutionState } from "./execution-state.ts";
export interface ExecutionOverlayProps {
    scene: Scene;
    execution: DiagramExecutionState;
    theme: DiagramTheme;
    fontProvider?: SkTypefaceFontProvider;
    assets?: NativeRenderAssets;
    onError?: (error: unknown) => void;
}
/** Local state overlays reuse measured geometry. Only a state/font/theme change
 * records these small Pictures; pulse and path progress remain on the UI thread. */
export declare function ExecutionOverlay({ scene, execution, theme, fontProvider, assets, onError, }: ExecutionOverlayProps): import("react").JSX.Element | null;
