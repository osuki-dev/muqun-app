import { type DiagramMotionPolicy } from "../motion-policy.ts";
export declare const sankeyMotion: DiagramMotionPolicy;
