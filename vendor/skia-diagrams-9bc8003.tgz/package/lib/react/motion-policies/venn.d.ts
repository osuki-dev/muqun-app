import { type DiagramMotionPolicy } from "../motion-policy.ts";
/** Set contours retain their intersections throughout entrance; labels follow overlaps. */
export declare const vennMotion: DiagramMotionPolicy;
