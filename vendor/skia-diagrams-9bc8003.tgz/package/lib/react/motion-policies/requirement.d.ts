import { type DiagramMotionPolicy } from "../motion-policy.ts";
/** Requirement identity precedes its fields, risk/verification status and relationships. */
export declare const requirementMotion: DiagramMotionPolicy;
