import { type DiagramMotionPolicy } from "../motion-policy.ts";
/** Exact source bit ranges drive reveal order, independent of MSB-first geometry. */
export declare const packetMotion: DiagramMotionPolicy;
