import { type DiagramMotionPolicy } from "../motion-policy.ts";
/** Authored wedges sweep in source order. Their values, leader and legend follow
 * that wedge; the heavy outer rim traces only after the data is visible. */
export declare const pieMotion: DiagramMotionPolicy;
