import { type DiagramMotionPolicy } from "../motion-policy.ts";
/** Ownership lanes stay fixed while tasks and handoffs progress in flow order. */
export declare const swimlanesMotion: DiagramMotionPolicy;
