import { type DiagramMotionPolicy } from "../motion-policy.ts";
/** Root first, then branch strokes and their complete node/icon/label groups.
 * Scale pivots belong to each group's node, avoiding a chart-wide text drift. */
export declare const mindmapMotion: DiagramMotionPolicy;
