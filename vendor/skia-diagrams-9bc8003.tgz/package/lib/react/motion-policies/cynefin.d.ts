import { type DiagramMotionPolicy } from "../motion-policy.ts";
/** Establish domain cards first, then reveal each domain's strategies independently. */
export declare const cynefinMotion: DiagramMotionPolicy;
