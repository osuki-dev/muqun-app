import { type DiagramMotionPolicy } from "../motion-policy.ts";
/** Authored frame order drives commands, events, projections and outgoing causality. */
export declare const eventmodelingMotion: DiagramMotionPolicy;
