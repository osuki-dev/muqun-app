import { type DiagramMotionPolicy } from "../motion-policy.ts";
/** Parent frames precede descendant tiles; area encodes data rather than animation scale. */
export declare const treemapMotion: DiagramMotionPolicy;
