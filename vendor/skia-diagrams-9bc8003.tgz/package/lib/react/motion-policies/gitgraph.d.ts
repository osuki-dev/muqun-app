import { type DiagramMotionPolicy } from "../motion-policy.ts";
/** Branch connections precede their chronological commits; tags and labels
 * belong to that commit's phase rather than a chart-wide text fade. */
export declare const gitgraphMotion: DiagramMotionPolicy;
