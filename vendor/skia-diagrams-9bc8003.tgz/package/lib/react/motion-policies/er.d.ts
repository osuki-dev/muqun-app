import { type DiagramMotionPolicy } from "../motion-policy.ts";
/** Entity attributes enter as complete rows so keys, types and comments stay together. */
export declare const erMotion: DiagramMotionPolicy;
