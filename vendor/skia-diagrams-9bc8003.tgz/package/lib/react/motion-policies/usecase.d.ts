import { type DiagramMotionPolicy } from "../motion-policy.ts";
/** Actors remain anchors while use cases settle, notes lift and authored relations trace. */
export declare const usecaseMotion: DiagramMotionPolicy;
