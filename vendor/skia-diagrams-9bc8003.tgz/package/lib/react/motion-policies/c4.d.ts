import { type DiagramMotionPolicy } from "../motion-policy.ts";
/** Stable boundaries establish context before dependent systems assemble and links trace. */
export declare const c4Motion: DiagramMotionPolicy;
