import { type DiagramMotionPolicy } from "../motion-policy.ts";
/** Every task reveals from its own start date; schedule axes and labels stay anchored. */
export declare const ganttMotion: DiagramMotionPolicy;
