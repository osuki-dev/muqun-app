import { type DiagramMotionPolicy } from "../motion-policy.ts";
/** Lifelines keep their authored order while message trajectories follow source to target. */
export declare const sequenceMotion: DiagramMotionPolicy;
