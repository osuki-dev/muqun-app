import { type DiagramMotionPolicy } from "../motion-policy.ts";
/** Class names, attributes, methods and relationships have separate reveal phases. */
export declare const classMotion: DiagramMotionPolicy;
