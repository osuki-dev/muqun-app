import type { Primitive, Scene } from "../../types.ts";
/** Iterative SCC condensation and longest-path ranks keep merges after every incoming branch. */
export declare function boardFlowRanks(scene: Scene): Map<string, number>;
export declare function boardFlowPhases(scene: Scene, count: number): Map<string, number>;
export declare function boardNodePhase(p: Primitive, phases: Map<string, number>): number;
