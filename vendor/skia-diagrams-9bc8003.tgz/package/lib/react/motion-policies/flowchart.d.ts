import { type DiagramMotionPolicy } from "../motion-policy.ts";
/** Structure is introduced in dependency order; execution is a separate host-controlled overlay. */
export declare const flowchartMotion: DiagramMotionPolicy;
