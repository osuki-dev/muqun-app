import { type DiagramMotionPolicy } from "../motion-policy.ts";
/** Author chronology owns the phases; the horizontal or vertical axis remains fixed. */
export declare const timelineMotion: DiagramMotionPolicy;
