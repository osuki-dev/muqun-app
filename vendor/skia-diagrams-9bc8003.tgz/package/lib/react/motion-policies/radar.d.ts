import { type DiagramMotionPolicy } from "../motion-policy.ts";
/** Axes remain readable while each authored series expands from the plot origin. */
export declare const radarMotion: DiagramMotionPolicy;
