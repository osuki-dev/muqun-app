import { type DiagramMotionPolicy } from "../motion-policy.ts";
/** Initial states lead into transitions; cycles remain finite and execution stays host-owned. */
export declare const stateMotion: DiagramMotionPolicy;
