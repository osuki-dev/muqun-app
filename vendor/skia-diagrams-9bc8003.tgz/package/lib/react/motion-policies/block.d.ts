import { type DiagramMotionPolicy } from "../motion-policy.ts";
/** Grid cells settle in reading order; authored links trace after cell assembly. */
export declare const blockMotion: DiagramMotionPolicy;
