import { type DiagramMotionPolicy } from "../motion-policy.ts";
/** Each authored task leads its satisfaction score and participating actor activity. */
export declare const journeyMotion: DiagramMotionPolicy;
