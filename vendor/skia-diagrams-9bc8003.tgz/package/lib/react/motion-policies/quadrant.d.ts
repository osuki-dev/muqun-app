import { type DiagramMotionPolicy } from "../motion-policy.ts";
/** Axes and region semantics stay fixed; authored data appears at its real location. */
export declare const quadrantMotion: DiagramMotionPolicy;
