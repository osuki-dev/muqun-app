import { type DiagramMotionPolicy } from "../motion-policy.ts";
/** Bars grow from the authored zero; line segments follow the categorical axis. */
export declare const xychartMotion: DiagramMotionPolicy;
