import { type DiagramMotionPolicy } from "../motion-policy.ts";
export declare const kanbanMotion: DiagramMotionPolicy;
