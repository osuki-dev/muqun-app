import { type DiagramMotionPolicy } from "../motion-policy.ts";
/** Components establish positions before dependencies and evolution movements appear. */
export declare const wardleyMotion: DiagramMotionPolicy;
