import { type DiagramMotionPolicy } from "../motion-policy.ts";
/** Establish deployment boundaries, then services, then their routed connections. */
export declare const architectureMotion: DiagramMotionPolicy;
