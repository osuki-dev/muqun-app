import { type SharedValue } from "react-native-reanimated";
export interface InlineZoomOptions {
    width: number;
    height: number;
    /** Scene dimensions before baseScale is applied. */
    contentWidth: number;
    contentHeight: number;
    baseScale: number;
    scrollX: SharedValue<number>;
    scrollY: SharedValue<number>;
    minFactor?: number;
    maxFactor?: number;
    onCommit: (factor: number, x: number, y: number) => void;
    onActiveChange?: (active: boolean) => void;
}
/** Pinch updates stay on the UI thread; committing updates native scroll extents
 * once. Pinching is direct manipulation and needs no motion preference override. */
export declare function useInlineZoom(options: InlineZoomOptions): {
    gesture: import("react-native-gesture-handler").ComposedGesture;
    zoom: any;
    pinching: any;
    lastEndedTimestamp: any;
    reset: () => void;
};
