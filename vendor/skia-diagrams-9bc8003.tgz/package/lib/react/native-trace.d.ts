import { type SharedValue } from "react-native-reanimated";
import type { DiagramTheme } from "../render/theme.ts";
import { type NativeTraceRecord, type TracePrimitive } from "./native-trace-core.ts";
export type { NativeTraceRecord } from "./native-trace-core.ts";
export declare function recordNativeTraces(primitives: readonly TracePrimitive[], theme: DiagramTheme): {
    traces: NativeTraceRecord[];
    resources: import("react-native-skia").SkPath[];
};
/** Native Skia trims the shaft on the UI thread; marker Pictures have separate timing. */
export declare function NativeTraces({ traces, progress, easing, }: {
    traces: readonly NativeTraceRecord[];
    progress: SharedValue<number>;
    easing?: "linear" | "ease-out";
}): import("react").JSX.Element;
