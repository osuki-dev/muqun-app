interface DeferredDriver {
    idle?: (work: () => void, timeout: number) => {
        cancel(): void;
    };
    timer: (work: () => void) => {
        cancel(): void;
    };
}
export declare function scheduleDiagramWork(work: () => void, driver?: DeferredDriver): {
    cancel(): void;
};
export {};
