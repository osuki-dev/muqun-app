import type { DiagramInteraction, Primitive, Scene } from "../types.ts";
/** Pie selection moves only chart geometry. Legends, titles and hit regions retain
 * their authored positions; the native host animates this logical-space vector. */
export declare function pieSelection(scene: Scene, selection: DiagramInteraction): {
    selected: Primitive[];
    other: Primitive[];
    fixed: Primitive[];
    row: number;
    offset: {
        x: number;
        y: number;
    };
} | undefined;
