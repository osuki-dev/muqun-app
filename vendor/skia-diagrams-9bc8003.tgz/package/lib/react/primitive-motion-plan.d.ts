import type { Primitive, Rect, Scene } from "../types.ts";
export type PrimitiveMotion = "trace" | "grow-x" | "grow-y" | "draw-x" | "draw-y" | "fade" | "lift" | "radial" | "scale";
export interface PrimitiveMotionLayer {
    primitives: Primitive[];
    mode: PrimitiveMotion;
    delay: number;
    /** Fraction of the shared timeline reserved for this semantic phase. */
    span?: number;
    /** Continuous sweeps avoid restarting an ease-out curve at each semantic phase. */
    easing?: "linear" | "ease-out";
    bounds: Rect;
    circle?: {
        cx: number;
        cy: number;
        radius: number;
        startAngle: number;
        sweepAngle: number;
    };
    baseline?: number;
    center?: {
        x: number;
        y: number;
    };
    regions?: Rect[];
}
export interface NumericMotion {
    delay?: number;
    span?: number;
    primitive: Extract<Primitive, {
        type: "text";
    }>;
    value: number;
    decimals: number;
    prefix: string;
    suffix: string;
}
export interface PrimitiveMotionPlan {
    staticPrimitives: Primitive[];
    layers: PrimitiveMotionLayer[];
    numbers: NumericMotion[];
}
/** Per-type policies prepare bounded disjoint records once, never on the animation thread. */
export declare function createPrimitiveMotionPlan(scene: Scene): PrimitiveMotionPlan;
