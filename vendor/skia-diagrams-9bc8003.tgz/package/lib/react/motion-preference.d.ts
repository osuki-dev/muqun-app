/** Reanimated's startup snapshot is supplemented by the live native preference. */
export declare function useReducedDiagramMotion(): boolean;
