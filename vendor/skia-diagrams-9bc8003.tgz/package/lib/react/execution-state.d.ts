import type { Primitive, Scene } from "../types.ts";
export type DiagramExecutionStatus = "idle" | "active" | "completed" | "error";
/** The host supplies actual process state; the renderer never advances it. */
export interface DiagramExecutionState {
    nodes?: Readonly<Record<string, DiagramExecutionStatus>>;
    edges?: Readonly<Record<string, DiagramExecutionStatus>>;
    revision?: string | number;
}
export interface ExecutionPrimitive {
    primitive: Primitive;
    status: Exclude<DiagramExecutionStatus, "idle">;
}
/** Match semantic source IDs, excluding inherited object properties and unknown
 * statuses. An omitted or idle item remains exactly as authored. */
export declare function executionPrimitives(scene: Scene, execution: DiagramExecutionState): ExecutionPrimitive[];
