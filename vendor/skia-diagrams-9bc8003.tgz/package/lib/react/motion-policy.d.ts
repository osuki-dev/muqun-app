import type { Primitive, Rect, Scene } from "../types.ts";
import type { PrimitiveMotionLayer, PrimitiveMotionPlan } from "./primitive-motion-plan.ts";
export type { NumericMotion, PrimitiveMotion, PrimitiveMotionLayer, PrimitiveMotionPlan, } from "./primitive-motion-plan.ts";
export type DiagramMotionPolicy = (scene: Scene) => PrimitiveMotionPlan;
export type MotionLayerOptions = Omit<PrimitiveMotionLayer, "primitives" | "bounds" | "delay"> & {
    delay?: number;
    bounds?: Rect;
};
export declare function motionBounds(primitives: readonly Primitive[], fallback: Rect): Rect;
/** Leaf policies own semantic classification. The collector guarantees one owner per original primitive. */
export declare function createMotionCollector(scene: Scene): {
    static(p: Primitive): void;
    number(p: Primitive, timing?: {
        delay?: number;
        span?: number;
    }): boolean;
    layer(p: Primitive, key: string, options: MotionLayerOptions): void;
    finish(): PrimitiveMotionPlan;
};
