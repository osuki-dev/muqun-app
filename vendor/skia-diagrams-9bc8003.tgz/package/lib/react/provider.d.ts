import { type ReactNode } from "react";
import type { SkTypefaceFontProvider } from "react-native-skia";
import { type DiagramTheme } from "../render/theme.ts";
import type { DiagramIconResolver, DiagramInteraction, TextMeasurer } from "../types.ts";
import type { NativeRenderAssets } from "../render/skia.ts";
import type { StyleProp, ViewStyle } from "react-native";
export interface DiagramExpandIconProps {
    color: string;
    size: number;
}
export type DiagramViewerIconAction = "close" | "fit" | "copy" | "success";
export interface DiagramViewerIconProps {
    action: DiagramViewerIconAction;
    color: string;
    size: number;
}
export interface DiagramConfiguration {
    theme?: Partial<DiagramTheme>;
    mode?: "light" | "dark";
    /** Host-owned and registered font aliases; the library ships no font assets. */
    fontProvider?: SkTypefaceFontProvider;
    measure?: TextMeasurer;
    resolveIcon?: DiagramIconResolver;
    /** Host owns decoded images and their lifetime. Replace the map when assets change. */
    assets?: NativeRenderAssets;
    /** System reduced-motion still takes precedence. */
    motion?: false | {
        duration?: number;
    };
    /** Host handles modal presentation. Canvas taps never invoke expansion. */
    onExpand?: (source: string) => void;
    /** Replace the default magnifier; button interaction and accessibility remain built in. */
    renderExpandIcon?: (props: DiagramExpandIconProps) => ReactNode;
    /** Replace viewer action icons; null/undefined retain the default for that action. */
    renderViewerIcon?: (props: DiagramViewerIconProps) => ReactNode;
    /** Style the visible expand button without changing its native touch target. */
    expandButtonStyle?: StyleProp<ViewStyle>;
    /** Host owns navigation and callback execution for authored Mermaid click targets. */
    onInteraction?: (interaction: DiagramInteraction) => void;
    /** Normal-flow selected-data content below the canvas. */
    renderDataDetail?: (selection: DiagramInteraction, dismiss: () => void) => ReactNode;
}
export declare const useDiagramConfiguration: () => DiagramConfiguration;
/** Nested providers inherit configuration; local component props override it. */
export declare function DiagramProvider({ children, ...configuration }: DiagramConfiguration & {
    children: ReactNode;
}): import("react").JSX.Element;
