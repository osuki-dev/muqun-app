export declare function diagramMotionDuration(kind: string, override?: number): number;
