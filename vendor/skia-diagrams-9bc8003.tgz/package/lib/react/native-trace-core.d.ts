import type { Skia, SkPath } from "react-native-skia";
import type { Point, Primitive } from "../types.ts";
import { type DiagramTheme } from "../render/theme.ts";
export type TracePrimitive = Extract<Primitive, {
    type: "path";
}>;
type PathApi = Pick<typeof Skia, "PathBuilder">;
export interface NativeTraceRecord {
    path: SkPath;
    color: string;
    width: number;
    opacity: number;
    dash?: number[];
    gradient?: {
        from: Point;
        to: Point;
        colors: string[];
        positions: number[];
    };
}
/** The same marker-shortened shaft and cubic interpolation used by the renderer. */
export declare function createNativeStrokePathWithApi(api: PathApi, p: TracePrimitive, theme: DiagramTheme): SkPath;
/** Ownership transfers to the caller only after the complete bundle succeeds. */
export declare function recordNativeTracesWithApi(api: PathApi, primitives: readonly TracePrimitive[], theme: DiagramTheme): {
    traces: NativeTraceRecord[];
    resources: SkPath[];
};
export {};
