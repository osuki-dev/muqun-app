import type { resolveDiagramTheme } from "../render/theme.ts";
/** Reading appearance does not run a diagram grammar; preparation owns syntax errors. */
export declare function readDiagramThemeDirective(source: string): Parameters<typeof resolveDiagramTheme>[2];
