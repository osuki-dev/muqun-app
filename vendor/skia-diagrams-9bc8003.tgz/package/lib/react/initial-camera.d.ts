import type { Scene } from "../types.ts";
/** Start natural-size mindmaps at their authored root; other diagrams retain
 * their existing top-left reading order. Layout geometry remains unchanged. */
export declare function initialDiagramCamera(scene: Scene, viewport: {
    width: number;
    height: number;
    scale: number;
}): {
    x: number;
    y: number;
};
