import type { Scene } from "../types.ts";
import type { DiagramTheme } from "./theme.ts";
/** Reject unsafe numbers before crossing JSI or allocating native resources.
 * Shared public drawing entries call this once; validated replay stays private. */
export declare function validateNativeScene(scene: Scene, theme: DiagramTheme): void;
