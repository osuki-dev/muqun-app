import type { Point, Rect, Shape } from "../types.ts";
/** Shared native/SVG contours. Coordinates and decorations stay inside the node bounds. */
export type ShapeCommand = {
    kind: "move" | "line";
    point: Point;
} | {
    kind: "curve";
    control1: Point;
    control2: Point;
    point: Point;
} | {
    kind: "close";
};
export interface ShapeContour {
    commands: ShapeCommand[];
    fill: boolean;
    ink?: boolean;
}
export declare function modernShapeContours(shape: Shape, rect: Rect): ShapeContour[] | undefined;
/** Flattening is only used for ray intersections; drawing retains exact cubic curves. */
export declare function contourPoints(commands: ShapeCommand[]): Point[];
export declare function contourSvg(commands: ShapeCommand[]): string;
