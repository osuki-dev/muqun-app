import type { LayoutOptions, Style } from "../types.ts";
export interface DiagramTheme {
    background: string;
    nodeFill: string;
    nodeStroke: string;
    nodeText: string;
    edgeStroke: string;
    edgeText: string;
    edgeTextBackground: string;
    clusterFill: string;
    clusterStroke: string;
    clusterText: string;
    accent: string;
    noteFill: string;
    noteText: string;
    fontFamily: string;
    fontFamilyMono: string;
    fontSize: number;
    strokeWidth: number;
    /** Native control borders; omitted values use the host platform hairline. */
    controlBorderWidth?: number;
    radius: number;
    palette: string[];
    /** Soft category surfaces used by the approved node and table design. */
    paletteFill?: string[];
    /** Text on filled chart categories; hosts can pair this with their palette. */
    paletteText?: string[];
    /** Optional geometry tokens; fontSize remains the theme's authoritative size. */
    layout?: Omit<LayoutOptions, "fontSize" | "radius">;
    arrowSize?: number;
    /** Optional modern roles fall back to existing host colors when omitted. */
    headerFill?: string;
    headerText?: string;
    mutedText?: string;
    gridStroke?: string;
    /** Ratios to strokeWidth; explicit Mermaid stroke widths remain absolute. */
    lineWeights?: Partial<Record<NonNullable<Style["strokeRole"]>, number>>;
}
/** Standalone snapshot of Muqun's Osuki pack, read 2026-10-06 from
 * app/src/constants/theme-packs.ts (Osuki colors and terminal ANSI accents).
 * No runtime import/dependency. The approved design uses stronger slate outlines
 * and neutral header bands over the pack's paper/ink/coral. Hosts override every token. */
export declare const lightTheme: DiagramTheme;
export declare const darkTheme: DiagramTheme;
/** Merge known nested theme groups without mutating host objects or replacing siblings. */
export declare function mergeThemeOverrides(base?: Partial<DiagramTheme>, override?: Partial<DiagramTheme>): Partial<DiagramTheme> | undefined;
export declare function resolveDiagramTheme(overrides?: Partial<DiagramTheme>, mode?: "light" | "dark", directive?: {
    theme?: "light" | "dark";
    variables?: Record<string, unknown>;
}): DiagramTheme;
export declare function resolveColor(value: string | undefined, fallback: string, theme: DiagramTheme): string;
export declare function resolveStrokeWidth(style: Pick<Style, "strokeWidth" | "strokeRole">, theme: DiagramTheme): number;
