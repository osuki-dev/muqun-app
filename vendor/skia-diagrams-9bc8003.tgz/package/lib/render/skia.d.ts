import type { Skia, SkCanvas, SkPicture, SkTypefaceFontProvider, SkImage } from "react-native-skia";
/** Host-decoded images are borrowed; the renderer never fetches or disposes them. */
export interface NativeRenderAssets {
    images?: ReadonlyMap<string, SkImage>;
}
type SkiaApi = Pick<typeof Skia, "ParagraphBuilder" | "Paint" | "Color" | "PathBuilder" | "PathEffect" | "XYWHRect" | "RRectXY" | "PictureRecorder" | "Surface" | "Shader">;
import type { Scene, TextMeasurer } from "../types.ts";
import { type DiagramTheme } from "./theme.ts";
/** Dependency injection permits CanvasKit goldens to execute the production renderer. */
export declare function createSkiaTextMeasurer(api: SkiaApi, theme: Pick<DiagramTheme, "fontFamily">, fonts?: SkTypefaceFontProvider): TextMeasurer;
export declare function drawScene(api: SkiaApi, canvas: SkCanvas, scene: Scene, theme: DiagramTheme, fonts?: SkTypefaceFontProvider, drawBackground?: boolean, assets?: NativeRenderAssets, markerOnly?: boolean): void;
export declare function renderToPicture(api: SkiaApi, scene: Scene, theme: DiagramTheme, fonts?: SkTypefaceFontProvider, assets?: NativeRenderAssets, options?: {
    drawBackground?: boolean;
    markerOnly?: boolean;
}): SkPicture;
export declare function renderToPng(api: SkiaApi, scene: Scene, theme: DiagramTheme, pixelRatio?: number, fonts?: SkTypefaceFontProvider, assets?: NativeRenderAssets): Uint8Array;
export {};
