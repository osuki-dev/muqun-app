export interface TextRun {
    text: string;
    bold?: boolean;
    italic?: boolean;
}
/** Restricted Markdown emphasis only; never HTML, scripts, links or callbacks. */
export declare function textRuns(source: string, literal?: boolean): TextRun[];
/** Preserve restricted emphasis across measured line breaks and ellipsis. */
export declare function runsForLines(source: string, lines: string[], literal?: boolean): TextRun[][];
