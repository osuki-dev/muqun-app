import type { Scene } from "../types.ts";
import { type DiagramTheme } from "./theme.ts";
export declare function escapeXml(text: string): string;
export declare function renderToSvg(scene: Scene, theme?: DiagramTheme): string;
