import type { Marker, Point, Rect, Shape } from "../types.ts";
export declare function intersectShape(shape: Shape, rect: Rect, toward: Point, radius?: number): Point;
export declare function shapePoints(shape: Shape, r: Rect): Point[];
export declare function markerPoints(marker: Marker, tip: Point, previous: Point, size?: number): Point[];
/** A cross has two independent strokes, not a connected four-point polyline. */
export declare function markerGeometry(marker: Marker, tip: Point, previous: Point, size?: number): {
    paths: Point[][];
    closed: boolean;
    filled: boolean;
};
/** The circle's outer tangent, not its center, touches a node boundary. */
export declare function circleMarkerCenter(tip: Point, previous: Point, radius?: number): Point;
/** Keep the shaft out of hollow UML terminals without painting an opaque mask
 * over a cluster or host background. Marker geometry still uses the original tip. */
export declare function markerShaft(points: Point[], start?: Marker, end?: Marker, size?: number): Point[];
/** Cubic ellipse approximation shared by both renderers, entirely inside bounds. */
export declare function cylinderGeometry(rect: Rect): {
    start: {
        x: number;
        y: number;
    };
    top: {
        control1: {
            x: number;
            y: number;
        };
        control2: {
            x: number;
            y: number;
        };
        end: {
            x: number;
            y: number;
        };
    }[];
    side: {
        x: number;
        y: number;
    };
    bottom: {
        control1: {
            x: number;
            y: number;
        };
        control2: {
            x: number;
            y: number;
        };
        end: {
            x: number;
            y: number;
        };
    }[];
    rim: {
        control1: {
            x: number;
            y: number;
        };
        control2: {
            x: number;
            y: number;
        };
        end: {
            x: number;
            y: number;
        };
    }[];
};
/** Round only the routed corners. Each cubic stays inside the convex hull of
 * its trim points and corner, unlike Catmull-Rom which can overshoot into nodes.
 * The untrimmed terminal legs keep marker tangents aligned with node contact. */
export declare function curveSegments(points: Point[]): {
    control1: Point;
    control2: Point;
    end: Point;
}[];
export declare function erMarkerGeometry(marker: Marker, tip: Point, previous: Point): {
    lines: Point[][];
    circles: Point[];
} | undefined;
export interface CubicSegment {
    control1: Point;
    control2: Point;
    end: Point;
}
/** Subdivide authored cubics when a hollow marker consumes the terminal shaft.
 * Interior controls remain exact; sampled arc length only locates the cut parameter. */
export declare function cubicMarkerShaft(start: Point, curves: CubicSegment[], first?: Marker, last?: Marker, size?: number): {
    start: Point;
    curves: CubicSegment[];
};
